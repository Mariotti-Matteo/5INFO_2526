import { c as create_ssr_component, e as escape, d as null_to_empty, f as createEventDispatcher, v as validate_component, h as add_attribute, i as each } from "../../chunks/ssr.js";
const icon_svelte_svelte_type_style_lang = "";
const css$5 = {
  code: ".icon.svelte-y47uu9{color:var(--color);font-size:32px}.icon.svelte-y47uu9:hover{cursor:pointer}",
  map: null
};
const Icon = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { name } = $$props;
  let { handler = () => {
  } } = $$props;
  let { color = "green" } = $$props;
  if ($$props.name === void 0 && $$bindings.name && name !== void 0)
    $$bindings.name(name);
  if ($$props.handler === void 0 && $$bindings.handler && handler !== void 0)
    $$bindings.handler(handler);
  if ($$props.color === void 0 && $$bindings.color && color !== void 0)
    $$bindings.color(color);
  $$result.css.add(css$5);
  return `${$$result.head += `<!-- HEAD_svelte-1wzvdnk_START --><link href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined" rel="stylesheet"><!-- HEAD_svelte-1wzvdnk_END -->`, ""}  <span class="material-icons-outlined icon svelte-y47uu9" style="${"--color:" + escape(color, true) + ";"}">${escape(name)} </span>`;
});
const cell_svelte_svelte_type_style_lang = "";
const css$4 = {
  code: ".cell.svelte-ir89wu{border-bottom:1px solid #E7ECEE;border-right:1px solid #E7ECEE;text-align:center;padding-top:10px;color:#525252;line-height:32px;font-size:18px}.cell-last.svelte-ir89wu{border-right:none}",
  map: null
};
const Cell = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { last = false } = $$props;
  if ($$props.last === void 0 && $$bindings.last && last !== void 0)
    $$bindings.last(last);
  $$result.css.add(css$4);
  return `<div class="${"cell " + escape(last ? "cell-last" : "", true) + " svelte-ir89wu"}">${slots.default ? slots.default({}) : ``} </div>`;
});
const priority_svelte_svelte_type_style_lang = "";
const css$3 = {
  code: "span.svelte-l24lca{display:inline-block;border-radius:5px;color:white;font-weight:bold;width:100px;height:30px}span.svelte-l24lca:hover{cursor:pointer}.ALTA.svelte-l24lca{background-color:red}.MEDIA.svelte-l24lca{background-color:orange}.BASSA.svelte-l24lca{background-color:green}.DISABILITATO.svelte-l24lca{background-color:grey}",
  map: null
};
const Priority = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { prio = 3 } = $$props;
  let { disabled = false } = $$props;
  const prio2str = (prio2) => {
    let map = { 1: "ALTA", 2: "MEDIA", 3: "BASSA" };
    return map[prio2];
  };
  if ($$props.prio === void 0 && $$bindings.prio && prio !== void 0)
    $$bindings.prio(prio);
  if ($$props.disabled === void 0 && $$bindings.disabled && disabled !== void 0)
    $$bindings.disabled(disabled);
  $$result.css.add(css$3);
  return `<span class="${escape(null_to_empty(disabled ? "DISABILITATO" : prio2str(prio)), true) + " svelte-l24lca"}">${escape(prio2str(prio))} </span>`;
});
const todo_item_svelte_svelte_type_style_lang = "";
const css$2 = {
  code: ".todo-item-input-text.svelte-1uomhok{border:none;width:90%;height:30px;font-size:20px;color:#525252}.todo-item-input-text.svelte-1uomhok:focus{background-color:rgb(204, 229, 253);color:black;padding:4px;padding-left:10px}.text-done.svelte-1uomhok{text-decoration:line-through;opacity:0.3}",
  map: null
};
const Todo_item = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { todo } = $$props;
  let old_priority = todo.priority;
  const dispatch = createEventDispatcher();
  const item_change = (type) => {
    dispatch("change", { type, id: todo.id });
  };
  const toggle_status = () => {
    todo.done = !todo.done;
    item_change("update");
  };
  if ($$props.todo === void 0 && $$bindings.todo && todo !== void 0)
    $$bindings.todo(todo);
  $$result.css.add(css$2);
  let $$settled;
  let $$rendered;
  do {
    $$settled = true;
    {
      {
        if (todo.priority != old_priority) {
          old_priority = todo.priority;
          item_change("update");
        }
      }
    }
    $$rendered = `${validate_component(Cell, "Cell").$$render($$result, {}, {}, {
      default: () => {
        return `${escape(todo.id)}`;
      }
    })} ${validate_component(Cell, "Cell").$$render($$result, {}, {}, {
      default: () => {
        return `${todo.done == false ? `${validate_component(Icon, "Icon").$$render(
          $$result,
          {
            name: "circle",
            handler: toggle_status,
            color: "red"
          },
          {},
          {}
        )}` : `${validate_component(Icon, "Icon").$$render($$result, { name: "task_alt", handler: toggle_status }, {}, {})}`}`;
      }
    })} ${validate_component(Cell, "Cell").$$render($$result, {}, {}, {
      default: () => {
        return `<input type="text" class="${"todo-item-input-text " + escape(todo.done == true ? "text-done" : "", true) + " svelte-1uomhok"}"${add_attribute("id", todo.id, 0)} placeholder="Inserisci il nuovo ToDo"${add_attribute("value", todo.task, 0)}>`;
      }
    })} ${validate_component(Cell, "Cell").$$render($$result, {}, {}, {
      default: () => {
        return `${validate_component(Priority, "Priority").$$render(
          $$result,
          { disabled: todo.done, prio: todo.priority },
          {
            prio: ($$value) => {
              todo.priority = $$value;
              $$settled = false;
            }
          },
          {}
        )}`;
      }
    })} ${validate_component(Cell, "Cell").$$render($$result, { last: true }, {}, {
      default: () => {
        return `${validate_component(Icon, "Icon").$$render(
          $$result,
          {
            name: "delete_forever",
            color: "red",
            handler: () => item_change("delete")
          },
          {},
          {}
        )}`;
      }
    })}`;
  } while (!$$settled);
  return $$rendered;
});
const todo_list_svelte_svelte_type_style_lang = "";
const css$1 = {
  code: "@import url('https://fonts.googleapis.com/css2?family=Permanent+Marker&display=swap');.app-title.svelte-k78ie3{font-family:'Permanent Marker', cursive;margin-top:0px;font-size:60px;opacity:0.3}.todo-list.svelte-k78ie3{display:grid;grid-template-columns:1fr 1fr 4fr 2fr 1fr;border:0px solid blue;width:95%;margin:auto}.header.svelte-k78ie3{border-bottom:1px solid #E7ECEE;border-right:1px solid #E7ECEE;text-align:center;padding-bottom:20px}.header-last.svelte-k78ie3{border-right:none}",
  map: null
};
const Todo_list = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let todos = [];
  let last_id = 0;
  let todo = {
    //ToDo Item
    id: last_id,
    task: "",
    done: false,
    priority: 3
  };
  const create_todo = async () => {
    todo = {
      id: ++last_id,
      task: "",
      done: false,
      priority: 3
    };
    console.log("CREATE:", todo);
    localStorage.setItem(`todo${todo.id}`, JSON.stringify(todo));
    todos = [...todos, todo];
  };
  $$result.css.add(css$1);
  return `<h1 class="app-title svelte-k78ie3" data-svelte-h="svelte-nh6ksq">ToDos</h1> <div class="todo-list svelte-k78ie3"><div class="header svelte-k78ie3">${validate_component(Icon, "Icon").$$render($$result, { name: "tag" }, {}, {})}</div> <div class="header svelte-k78ie3">${validate_component(Icon, "Icon").$$render($$result, { name: "task_alt" }, {}, {})}</div> <div class="header svelte-k78ie3">${validate_component(Icon, "Icon").$$render($$result, { name: "list" }, {}, {})}</div> <div class="header svelte-k78ie3">${validate_component(Icon, "Icon").$$render($$result, { name: "schedule" }, {}, {})}</div> <div class="header header-last svelte-k78ie3">${validate_component(Icon, "Icon").$$render($$result, { name: "add_box", handler: create_todo }, {}, {})}</div>  ${each(todos, (todo2) => {
    return `${validate_component(Todo_item, "TodoItem").$$render($$result, { todo: todo2 }, {}, {})}`;
  })} </div>`;
});
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "main.svelte-ufi2dx{border:0px solid red;width:60%;margin:auto}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<main class="svelte-ufi2dx">${validate_component(Todo_list, "TodoList").$$render($$result, {}, {}, {})} </main>`;
});
export {
  Page as default
};
