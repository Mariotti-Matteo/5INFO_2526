

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.48c33cbc.js","_app/immutable/chunks/scheduler.dbf07e93.js","_app/immutable/chunks/index.f9596564.js"];
export const stylesheets = [];
export const fonts = [];
