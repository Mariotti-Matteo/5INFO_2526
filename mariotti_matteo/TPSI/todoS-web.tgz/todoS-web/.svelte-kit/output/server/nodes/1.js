

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.043eab1d.js","_app/immutable/chunks/scheduler.dbf07e93.js","_app/immutable/chunks/index.f9596564.js","_app/immutable/chunks/singletons.316bf43d.js"];
export const stylesheets = [];
export const fonts = [];
