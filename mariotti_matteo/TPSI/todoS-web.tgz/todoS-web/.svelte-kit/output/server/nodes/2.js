import * as server from '../entries/pages/_page.server.js';

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/+page.server.js";
export const imports = ["_app/immutable/nodes/2.b5b39fa7.js","_app/immutable/chunks/scheduler.dbf07e93.js","_app/immutable/chunks/index.f9596564.js"];
export const stylesheets = ["_app/immutable/assets/2.eb5b2587.css"];
export const fonts = [];
